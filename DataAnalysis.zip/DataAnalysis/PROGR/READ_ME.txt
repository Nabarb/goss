Marianna Semprini
IIT, May 2018


INSTRUCTIONS FOR DATA ANALYSIS SW
1) Set the parameters and insert/select the files in the script GP_set_FileList_script (script folder).
2) Set the root directories in the GP_dir_opts_REPOSITORY file (repository folder).
3) Run one of the scripts in the script folder.